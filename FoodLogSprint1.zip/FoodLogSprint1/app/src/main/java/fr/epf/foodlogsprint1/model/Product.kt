package fr.epf.foodlogsprint1.model

import android.os.Build
import androidx.annotation.RequiresApi
import java.time.LocalDate
import java.util.*

enum class CategoryProduct {
    FRUIT, LEGUME, CEREALE, LAITIER, SUCRE, SALE, VIANDE, POISSON, BOISSON
}

data class Product(
    val nom: String,
    val category: CategoryProduct,
    val date: LocalDate
) {
    /*val=valeur non modifiable*/
    companion object { /*  all: même chose que :ListClient<>*/
        /*val all = (1..20).map{
            /*Product("nom$it", if(it%3 == 0) CategoryProduct.FRUIT else CategoryProduct.LEGUME, Date(20201212))*/
            Product("Pomme PinkLady", CategoryProduct.FRUIT, Date(20201212))
            Product("Carotte", CategoryProduct.LEGUME, Date(20201212))
        }.toMutableList()*/
        @RequiresApi(Build.VERSION_CODES.O)
        val all = mutableListOf<Product>(
            Product("Pomme Pink Lady", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Aubergine", CategoryProduct.LEGUME, LocalDate.of(2020, 3, 30)),
            Product("Côte de boeuf", CategoryProduct.VIANDE, LocalDate.of(2020, 3, 30)),
            Product("Dorade Grise", CategoryProduct.POISSON, LocalDate.of(2020, 4, 10)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2)),
            Product("Pomme", CategoryProduct.FRUIT, LocalDate.of(2020, 4, 2))
        )

        /*.filter {it.age >23} garde que les clients avec un age >23*/
    }
}

