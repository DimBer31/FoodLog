package fr.epf.foodlogsprint1.Options

import android.content.Intent
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import fr.epf.foodlogsprint1.R
import fr.epf.foodlogsprint1.model.Product
import kotlinx.android.synthetic.main.activity_details_product.*
import kotlinx.android.synthetic.main.activity_loading.view.*
import java.util.*

class DetailsProductActivity() : AppCompatActivity(){

    private var productLastName : String? = null
    private var id : Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details_product)

        product_imageView_details.setOnClickListener {
            var intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
            startActivity(intent)
        }

        id = intent.getIntExtra("id", 0)

        productLastName = intent.getStringExtra("clientLastName")
        details_nom.text= productLastName

        val clientSexe = intent.getStringExtra("clientGender")
        details_sexe.text= clientSexe

        product_imageView_details.setImageResource(
            when(clientSexe){
                "VIANDE" -> R.drawable.viande
                "LEGUME" -> R.drawable.aubergine
                "FRUIT" -> R.drawable.pomme
                "POISSON" -> R.drawable.poisson
                "CEREALE" -> R.drawable.cereale
                else -> R.drawable.banane
            }
        )
        /*if (clientSexe == "VIANDE"){
            product_imageView_details.setImageResource(R.drawable.viande)
        }*/


        val clientActive = intent.getStringExtra("clientActive")
        details_actif.text= clientActive

        Log.d("EPF", "enter")

    }

    /*permet d'ajouter le menu*/
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.detail_product, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when(item.itemId){
            R.id.action_delete -> {
                val builder = AlertDialog.Builder(this)
                builder.setTitle(R.string.product_delete_confirm_title)
                builder.setMessage(getString(R.string.product_delete_confirm_message, productLastName))
                builder.setNegativeButton(android.R.string.no){_,_ ->
                    Log.d("EPF", "Non supprimé")
                }
                builder.setPositiveButton(android.R.string.yes){_,_ ->
                    Product.all.removeAt(id)
                    finish()
                }

                builder.show()
                true
            }
            else -> false
        }
    }


}