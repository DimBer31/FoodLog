package fr.epf.foodlogsprint1.ListProduct

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import fr.epf.foodlogsprint1.Options.DetailsProductActivity
import fr.epf.foodlogsprint1.R
import fr.epf.foodlogsprint1.model.CategoryProduct
import fr.epf.foodlogsprint1.model.Product
import kotlinx.android.synthetic.main.product_view.view.*

class ProductAdapter(val products: List<Product>) : RecyclerView.Adapter<ProductAdapter.ProductViewHolder>() {
    class ProductViewHolder(val productView : View) : RecyclerView.ViewHolder(productView)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val layoutInflater : LayoutInflater = LayoutInflater.from(parent.context)
        val view: View = layoutInflater.inflate(R.layout.product_view, parent, false)
        return ProductViewHolder(
            view
        )
    }

    override fun getItemCount(): Int = products.size


    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = products[position]
        holder.productView.product_name_textview.text= "${product.nom}"
        holder.productView.product_imageview.setImageResource(
            when(product.category){
                CategoryProduct.FRUIT -> R.drawable.pomme
                CategoryProduct.LEGUME -> R.drawable.aubergine
                CategoryProduct.CEREALE -> R.drawable.pomme
                CategoryProduct.LAITIER -> R.drawable.banane
                CategoryProduct.SALE -> R.drawable.pomme
                CategoryProduct.SUCRE -> R.drawable.banane
                CategoryProduct.VIANDE -> R.drawable.viande
                CategoryProduct.POISSON -> R.drawable.poisson
                CategoryProduct.BOISSON -> R.drawable.pomme
            }
        )
        holder.productView.setOnClickListener {
            Log.d("EPF", "$product")
            val intent = Intent(it.context, DetailsProductActivity::class.java) /*this : représente HomeActivity*/
            intent.putExtra("id", position)
            intent.putExtra("clientLastName", product.nom)
            intent.putExtra("clientGender", "${product.category}")
            intent.putExtra("clientActive", "${product.date}")

            it.context.startActivity(intent)
        }
    }


}