package fr.epf.foodlogsprint1.Options

import android.app.DatePickerDialog
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.*
import androidx.annotation.RequiresApi
import fr.epf.foodlogsprint1.R
import fr.epf.foodlogsprint1.model.CategoryProduct
import fr.epf.foodlogsprint1.model.Product
import kotlinx.android.synthetic.main.activity_add_product.*
import java.time.LocalDate
import java.util.*

class AddProductActivity : AppCompatActivity() {

    private var mDisplayDate: TextView? = null
    private var mDateSetListener: DatePickerDialog.OnDateSetListener? = null

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_add_product)

        val levels = resources.getStringArray(R.array.level_array)
        val spinner = findViewById<Spinner>(R.id.level_spinner)

        if (spinner != null) {
            val adapter = ArrayAdapter(this,
                android.R.layout.simple_spinner_item, levels)
            spinner.adapter = adapter
            spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {

                }

                override fun onNothingSelected(parent: AdapterView<*>) {
                    // write code to perform some action
                }
            }
        }

        //                      DATEPICKER
        tvDate.setOnClickListener(View.OnClickListener {
            val cal: Calendar = Calendar.getInstance()
            val year: Int = cal.get(Calendar.YEAR)
            val month: Int = cal.get(Calendar.MONTH)
            val day: Int = cal.get(Calendar.DAY_OF_MONTH)
            val dialog = DatePickerDialog(
                this@AddProductActivity,
                mDateSetListener,
                year, month, day
            )
            dialog.show()
        })

        mDateSetListener =
            DatePickerDialog.OnDateSetListener { datePicker, year, month, day ->
                var month = month
                month = month + 1
                val date = "$year-$month-$day"
                tvDate.setText(date)
            }

        //                      AFFICHAGE LOGCAT
        add_product_button.setOnClickListener {
            val lastname = lastname_edittext.text
            val type : String = level_spinner.selectedItem as String
            var typeProduct : CategoryProduct = CategoryProduct.FRUIT
            when(type){
                "Légumes" -> typeProduct = CategoryProduct.LEGUME
                "Fruits" -> typeProduct = CategoryProduct.FRUIT
                "Céréales et féculents" -> typeProduct = CategoryProduct.CEREALE
                "Produits laitiers" -> typeProduct = CategoryProduct.LAITIER
                "Produits sucrés" -> typeProduct = CategoryProduct.SUCRE
                "Produits salés" -> typeProduct = CategoryProduct.SALE
                "Viandes" -> typeProduct = CategoryProduct.VIANDE
                "Poissons" -> typeProduct = CategoryProduct.POISSON
                "Boissons" -> typeProduct = CategoryProduct.BOISSON
            }

            val date = LocalDate.parse(tvDate.text)


            Product.all.add(Product("${lastname}",typeProduct,date))

            Log.d("EPF", "Produit: ${lastname} - Type: ${typeProduct} - Date: ${date}")
            finish()
        }
    }




}
