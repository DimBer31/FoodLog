package fr.epf.foodlogsprint1.LoadingActivities

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import fr.epf.foodlogsprint1.ListProduct.ListProductActivity
import fr.epf.foodlogsprint1.R
import kotlinx.android.synthetic.main.activity_sign_up.*

class SignUpActivity : AppCompatActivity(){

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_up)

        register_button.setOnClickListener {
            val name_ = txtName.text.toString()
            val firstname_ = txtFirstname.text.toString()
            val email_registration = txtEmail.text.toString()
            val password_registration = txtPassword.text.toString()
            val password_confirmation = txtPasswordConfirmation.text.toString()

            val listActivity = Intent (this, ListProductActivity::class.java)
            startActivity(listActivity)
        }


    }

}